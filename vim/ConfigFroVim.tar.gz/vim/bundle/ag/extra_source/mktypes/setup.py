from distutils.core import setup
import py2exe

# for console program use 'console = [{"script" : "scriptname.py"}]
setup(console=[{"script" : "../../mktypes.py"}])
